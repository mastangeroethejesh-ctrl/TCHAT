package com.example.data.remote

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun generateAiResponse(prompt: String, category: String = "General"): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isNullOrBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext getLocalSmartResponse(prompt, category)
        }

        val systemInstruction = "You are Techstarc AI, a highly capable assistant integrated into Tchat (by Techstarc.chat, founded by Thejesh). " +
                "You assist with coding, homework, startup brainstorming, message drafting, translation, and general questions. " +
                "Be concise, insightful, tech-forward, and adhere to clean markdown formatting."

        try {
            val jsonBody = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "user")
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", "$systemInstruction\n\nUser Question ($category): $prompt"))
                        })
                    })
                })
            }

            val requestBody = jsonBody.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey")
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseString = response.body?.string()

            if (response.isSuccessful && !responseString.isNullOrBlank()) {
                val jsonResponse = JSONObject(responseString)
                val candidates = jsonResponse.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val content = candidates.getJSONObject(0).optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        return@withContext parts.getJSONObject(0).optString("text", "No response received.")
                    }
                }
            }
            Log.w("GeminiService", "API call unsuccessful or empty: ${response.code}. Falling back.")
            getLocalSmartResponse(prompt, category)
        } catch (e: Exception) {
            Log.e("GeminiService", "Gemini call failed", e)
            getLocalSmartResponse(prompt, category)
        }
    }

    private fun getLocalSmartResponse(prompt: String, category: String): String {
        val lower = prompt.lowercase()
        return when {
            lower.contains("hello") || lower.contains("hi") ->
                "Hello! I am **Techstarc AI**, built for **Tchat** by **Techstarc.chat**, founded by **Thejesh**.\n\nHow can I accelerate your day? I can assist with:\n- **Coding & Architecture**\n- **Startup & Product Brainstorming**\n- **Message Summarization & Translations**\n- **Homework & Problem Solving**"

            lower.contains("who made") || lower.contains("thejesh") || lower.contains("company") ->
                "**Tchat** is developed by **Techstarc.chat**, founded by visionary technologist **Thejesh**! Tchat delivers high-performance real-time messaging, WebRTC calling, and integrated Gemini AI intelligence."

            category == "Coding" || lower.contains("code") || lower.contains("kotlin") || lower.contains("android") ->
                "Here is an architectural recommendation for your tech stack:\n```kotlin\n// Techstarc Clean Architecture Pattern\nclass MessagingEngine(private val signalingBackend: WebRtcSignaling) {\n    fun initiateSecureSession(peerId: String) {\n        // High speed P2P exchange\n    }\n}\n```\nAlways decouple UI State from network pipelines using Kotlin Flow and StateFlow."

            category == "Startup" || lower.contains("startup") || lower.contains("business") || lower.contains("idea") ->
                "**Startup Brainstorming Framework (Techstarc Method):**\n1. **High Friction Problem**: Identify where modern workflows break down.\n2. **Unfair Speed**: Deliver an experience 10x faster than incumbents.\n3. **Network Density**: Create communication loops that bring teams together."

            lower.contains("summarize") || category == "Summary" ->
                "**Summary of Topic:**\n- Core takeaway: High-efficiency communication reduces context switching.\n- Key action: Prioritize direct, low-latency channels with real-time feedback loops."

            else ->
                "**Techstarc AI Analysis:**\nRegarding \"$prompt\":\nFocused execution and streamlined communication are essential for modern product teams. Tchat integrates real-time messaging, crystal-clear WebRTC audio/video, and Gemini intelligence into a single unified workspace."
        }
    }
}
