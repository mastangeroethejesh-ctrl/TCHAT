package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.model.*

@Database(
    entities = [
        User::class,
        Conversation::class,
        Message::class,
        CallLog::class,
        StatusUpdate::class,
        Community::class,
        AiMessage::class
    ],
    version = 1,
    exportSchema = false
)
abstract class TchatDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun messageDao(): MessageDao
    abstract fun callDao(): CallDao
    abstract fun statusDao(): StatusDao
    abstract fun communityDao(): CommunityDao
    abstract fun aiDao(): AiDao

    companion object {
        @Volatile
        private var INSTANCE: TchatDatabase? = null

        fun getInstance(context: Context): TchatDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TchatDatabase::class.java,
                    "tchat_database.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
