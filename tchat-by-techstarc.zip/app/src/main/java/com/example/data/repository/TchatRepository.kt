package com.example.data.repository

import android.content.Context
import com.example.data.local.TchatDatabase
import com.example.data.remote.GeminiService
import com.example.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class TchatRepository(context: Context) {
    private val db = TchatDatabase.getInstance(context)
    private val chatDao = db.chatDao()
    private val messageDao = db.messageDao()
    private val callDao = db.callDao()
    private val statusDao = db.statusDao()
    private val communityDao = db.communityDao()
    private val aiDao = db.aiDao()
    private val geminiService = GeminiService()

    private val coroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    init {
        coroutineScope.launch {
            seedDefaultDataIfEmpty()
        }
    }

    fun getActiveConversations(): Flow<List<Conversation>> = chatDao.getActiveConversations()
    fun getArchivedConversations(): Flow<List<Conversation>> = chatDao.getArchivedConversations()
    fun getMessagesForConversation(conversationId: String): Flow<List<Message>> =
        messageDao.getMessagesForConversation(conversationId)
    fun getCallLogs(): Flow<List<CallLog>> = callDao.getCallLogs()
    fun getStatusUpdates(): Flow<List<StatusUpdate>> = statusDao.getStatusUpdates()
    fun getCommunities(): Flow<List<Community>> = communityDao.getCommunities()
    fun getAiMessages(): Flow<List<AiMessage>> = aiDao.getAiMessages()

    suspend fun getConversation(id: String): Conversation? = chatDao.getConversationById(id)

    suspend fun sendMessage(
        conversationId: String,
        text: String,
        type: String = "TEXT",
        mediaUrl: String = "",
        voiceDurationSeconds: Int = 0,
        replyToText: String = "",
        replyToSender: String = ""
    ) {
        val msgId = UUID.randomUUID().toString()
        val userMsg = Message(
            id = msgId,
            conversationId = conversationId,
            senderId = "me",
            senderName = "Me",
            text = text,
            timestamp = System.currentTimeMillis(),
            isFromMe = true,
            status = "SENDING",
            type = type,
            mediaUrl = mediaUrl,
            voiceDurationSeconds = voiceDurationSeconds,
            replyToText = replyToText,
            replyToSender = replyToSender
        )
        messageDao.insertMessage(userMsg)

        // Update conversation last message
        val conv = chatDao.getConversationById(conversationId)
        if (conv != null) {
            chatDao.updateConversation(
                conv.copy(
                    lastMessage = if (type == "VOICE") "🎤 Voice message ($voiceDurationSeconds s)" else text,
                    lastMessageTime = System.currentTimeMillis(),
                    typingStatus = ""
                )
            )
        }

        // Simulate real-time delivery lifecycle: SENDING -> DELIVERED -> READ
        coroutineScope.launch {
            delay(400)
            messageDao.updateMessage(userMsg.copy(status = "DELIVERED"))
            delay(800)
            messageDao.updateMessage(userMsg.copy(status = "READ"))

            // Trigger realistic contact reply
            simulateContactReply(conversationId, text)
        }
    }

    private suspend fun simulateContactReply(conversationId: String, userText: String) {
        val conv = chatDao.getConversationById(conversationId) ?: return
        delay(1200)
        // Show typing indicator
        chatDao.updateConversation(conv.copy(typingStatus = "typing..."))
        delay(2200)

        // Generate response based on contact
        val replyText = when {
            conv.id == "thejesh" -> {
                when {
                    userText.contains("call", ignoreCase = true) -> "Let's hop on a WebRTC video call right away!"
                    userText.contains("techstarc", ignoreCase = true) -> "Techstarc.chat is pushing the boundaries of communication tech. Glad you're enjoying Tchat!"
                    else -> "Got your message on Tchat. High-speed, high-fidelity communication is our hallmark!"
                }
            }
            conv.isGroup -> {
                "Team lead: Received and acknowledged on the Techstarc feed."
            }
            else -> {
                "Thanks for reaching out on Tchat! All messages synced in real-time."
            }
        }

        val replyMsg = Message(
            id = UUID.randomUUID().toString(),
            conversationId = conversationId,
            senderId = conv.id,
            senderName = conv.name,
            text = replyText,
            timestamp = System.currentTimeMillis(),
            isFromMe = false,
            status = "READ"
        )
        messageDao.insertMessage(replyMsg)
        chatDao.updateConversation(
            conv.copy(
                lastMessage = replyText,
                lastMessageTime = System.currentTimeMillis(),
                typingStatus = "",
                unreadCount = 0
            )
        )
    }

    suspend fun addReaction(messageId: String, reaction: String) {
        messageDao.updateReaction(messageId, reaction)
    }

    suspend fun toggleStar(messageId: String) {
        messageDao.toggleStar(messageId)
    }

    suspend fun deleteMessage(messageId: String) {
        messageDao.deleteMessage(messageId)
    }

    suspend fun togglePinChat(id: String) {
        chatDao.togglePin(id)
    }

    suspend fun toggleArchiveChat(id: String) {
        chatDao.toggleArchive(id)
    }

    suspend fun toggleMuteChat(id: String) {
        chatDao.toggleMute(id)
    }

    suspend fun deleteConversation(id: String) {
        chatDao.deleteConversation(id)
    }

    suspend fun createNewChat(name: String, isGroup: Boolean, initialMessage: String = ""): String {
        val newId = UUID.randomUUID().toString()
        val conv = Conversation(
            id = newId,
            name = name,
            isGroup = isGroup,
            lastMessage = initialMessage.ifEmpty { "Chat started" },
            lastMessageTime = System.currentTimeMillis(),
            unreadCount = 0,
            isOnline = !isGroup
        )
        chatDao.insertConversation(conv)
        if (initialMessage.isNotEmpty()) {
            val msg = Message(
                id = UUID.randomUUID().toString(),
                conversationId = newId,
                senderId = "me",
                senderName = "Me",
                text = initialMessage,
                timestamp = System.currentTimeMillis(),
                isFromMe = true,
                status = "READ"
            )
            messageDao.insertMessage(msg)
        }
        return newId
    }

    suspend fun recordCallLog(contactName: String, isVideo: Boolean, isOutgoing: Boolean, isMissed: Boolean, duration: String) {
        val log = CallLog(
            id = UUID.randomUUID().toString(),
            contactName = contactName,
            isVideo = isVideo,
            isOutgoing = isOutgoing,
            isMissed = isMissed,
            timestamp = System.currentTimeMillis(),
            durationText = duration
        )
        callDao.insertCallLog(log)
    }

    suspend fun postStatus(content: String, mediaType: String = "TEXT", bgHex: String = "#E53935") {
        val status = StatusUpdate(
            id = UUID.randomUUID().toString(),
            userId = "me",
            userName = "My Status",
            content = content,
            mediaType = mediaType,
            timestamp = System.currentTimeMillis(),
            bgHex = bgHex
        )
        statusDao.insertStatus(status)
    }

    suspend fun markStatusViewed(id: String) {
        statusDao.markStatusViewed(id)
    }

    suspend fun toggleCommunitySubscription(id: String) {
        communityDao.toggleSubscription(id)
    }

    suspend fun askTechstarcAi(prompt: String, category: String = "General"): String {
        val answer = geminiService.generateAiResponse(prompt, category)
        val aiMsg = AiMessage(
            prompt = prompt,
            response = answer,
            category = category
        )
        aiDao.insertAiMessage(aiMsg)
        return answer
    }

    private suspend fun seedDefaultDataIfEmpty() {
        val existing = chatDao.getConversationById("thejesh")
        if (existing == null) {
            val conversations = listOf(
                Conversation(
                    id = "thejesh",
                    name = "Thejesh (Founder)",
                    isGroup = false,
                    lastMessage = "Welcome to Tchat! Built for high-velocity teams at Techstarc.chat.",
                    lastMessageTime = System.currentTimeMillis() - 1000 * 60 * 5,
                    unreadCount = 1,
                    isPinned = true,
                    isOnline = true
                ),
                Conversation(
                    id = "techstarc_devs",
                    name = "Techstarc Engineering",
                    isGroup = true,
                    lastMessage = "WebRTC signaling server deployed with sub-50ms latency.",
                    lastMessageTime = System.currentTimeMillis() - 1000 * 60 * 30,
                    unreadCount = 2,
                    isPinned = true
                ),
                Conversation(
                    id = "alex_chen",
                    name = "Alex Chen",
                    isGroup = false,
                    lastMessage = "Check out the new cinematic animations in Tchat.",
                    lastMessageTime = System.currentTimeMillis() - 1000 * 60 * 120,
                    unreadCount = 0,
                    isOnline = true
                ),
                Conversation(
                    id = "sarah_product",
                    name = "Sarah Jenkins",
                    isGroup = false,
                    lastMessage = "Voice notes waveform feature is working smoothly!",
                    lastMessageTime = System.currentTimeMillis() - 1000 * 60 * 360,
                    unreadCount = 0,
                    isOnline = false
                ),
                Conversation(
                    id = "design_squad",
                    name = "Techstarc UI/UX Squad",
                    isGroup = true,
                    lastMessage = "Brand guidelines approved: White, Yellow (#FFC107), Red (#E53935) only.",
                    lastMessageTime = System.currentTimeMillis() - 1000 * 60 * 600,
                    unreadCount = 0
                )
            )
            chatDao.insertConversations(conversations)

            // Seed initial messages for Thejesh conversation
            val thejeshMessages = listOf(
                Message(
                    id = "msg_t1",
                    conversationId = "thejesh",
                    senderId = "thejesh",
                    senderName = "Thejesh",
                    text = "Welcome to Tchat! Proudly presented by Techstarc.chat.",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 10,
                    isFromMe = false,
                    status = "READ"
                ),
                Message(
                    id = "msg_t2",
                    conversationId = "thejesh",
                    senderId = "me",
                    senderName = "Me",
                    text = "Thanks Thejesh! The custom red and yellow palette looks great.",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 8,
                    isFromMe = true,
                    status = "READ"
                ),
                Message(
                    id = "msg_t3",
                    conversationId = "thejesh",
                    senderId = "thejesh",
                    senderName = "Thejesh",
                    text = "Feel free to test real-time chats, WebRTC calls, communities, and our built-in Techstarc AI!",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 5,
                    isFromMe = false,
                    status = "READ",
                    reactions = "🔥"
                )
            )
            messageDao.insertMessages(thejeshMessages)

            // Seed initial call logs
            val callLogs = listOf(
                CallLog(
                    id = "call_1",
                    contactName = "Thejesh (Founder)",
                    isVideo = true,
                    isOutgoing = false,
                    isMissed = false,
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 45,
                    durationText = "14m 20s"
                ),
                CallLog(
                    id = "call_2",
                    contactName = "Alex Chen",
                    isVideo = false,
                    isOutgoing = true,
                    isMissed = false,
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 180,
                    durationText = "4m 12s"
                ),
                CallLog(
                    id = "call_3",
                    contactName = "Sarah Jenkins",
                    isVideo = true,
                    isOutgoing = false,
                    isMissed = true,
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 400,
                    durationText = "Missed"
                )
            )
            callLogs.forEach { callDao.insertCallLog(it) }

            // Seed status updates
            val statuses = listOf(
                StatusUpdate(
                    id = "st_thejesh",
                    userId = "thejesh",
                    userName = "Thejesh (Founder)",
                    content = "🚀 Shipping Tchat worldwide. Fast, cinematic, built by Techstarc.chat!",
                    bgHex = "#E53935",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 60
                ),
                StatusUpdate(
                    id = "st_techstarc",
                    userId = "techstarc_news",
                    userName = "Techstarc Announcements",
                    content = "⚡ Techstarc AI integration now live! Powered by Google Gemini.",
                    bgHex = "#1E1E1E",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 150
                )
            )
            statuses.forEach { statusDao.insertStatus(it) }

            // Seed communities
            val communities = listOf(
                Community(
                    id = "comm_official",
                    name = "Techstarc.chat Official",
                    description = "Official announcements, updates, and releases from founder Thejesh.",
                    memberCount = 14250,
                    isBroadcastChannel = true,
                    isSubscribed = true,
                    latestAnnouncement = "Tchat v1.0 production build released with WebRTC calling & Gemini AI."
                ),
                Community(
                    id = "comm_android",
                    name = "Android & Kotlin Pioneers",
                    description = "Engineering discussions on Jetpack Compose, Coroutines, and Room.",
                    memberCount = 8400,
                    isBroadcastChannel = false,
                    isSubscribed = true,
                    latestAnnouncement = "Best practices for WebRTC audio streams in Jetpack Compose."
                ),
                Community(
                    id = "comm_startup",
                    name = "Techstarc Founders Club",
                    description = "Entrepreneurs and makers building high-growth tech ventures.",
                    memberCount = 5620,
                    isBroadcastChannel = false,
                    isSubscribed = false,
                    latestAnnouncement = "Weekly AMA with Thejesh on building real-time collaboration apps."
                )
            )
            communityDao.insertCommunities(communities)

            // Seed initial AI welcome message
            val welcomeAi = AiMessage(
                prompt = "What is Techstarc AI?",
                response = "I am **Techstarc AI**, powered by Google Gemini and built natively into **Tchat** by **Techstarc.chat**, founded by **Thejesh**.\n\nI can assist you with code debugging, architectural design, startup brainstorming, message drafting, homework, and translations. How can I help you today?",
                category = "General"
            )
            aiDao.insertAiMessage(welcomeAi)
        }
    }
}
