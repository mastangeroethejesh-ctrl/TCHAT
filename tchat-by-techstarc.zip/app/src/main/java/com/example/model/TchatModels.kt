package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey val id: String,
    val displayName: String,
    val username: String,
    val email: String,
    val phoneNumber: String = "",
    val bio: String = "Using Tchat by Techstarc.chat",
    val avatarUrl: String = "",
    val isOnline: Boolean = true,
    val lastSeen: Long = System.currentTimeMillis(),
    val statusPrivacy: String = "Everyone" // "Everyone", "Contacts", "Nobody"
)

@Entity(tableName = "conversations")
data class Conversation(
    @PrimaryKey val id: String,
    val name: String,
    val isGroup: Boolean = false,
    val lastMessage: String = "",
    val lastMessageTime: Long = System.currentTimeMillis(),
    val unreadCount: Int = 0,
    val avatarUrl: String = "",
    val isPinned: Boolean = false,
    val isMuted: Boolean = false,
    val isArchived: Boolean = false,
    val isOnline: Boolean = false,
    val typingStatus: String = "", // e.g., "typing..." or empty
    val disappearingMessages: String = "Off" // "Off", "24h", "7d"
)

@Entity(tableName = "messages")
data class Message(
    @PrimaryKey val id: String,
    val conversationId: String,
    val senderId: String,
    val senderName: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isFromMe: Boolean,
    val status: String = "READ", // "SENDING", "SENT", "DELIVERED", "READ"
    val type: String = "TEXT", // "TEXT", "IMAGE", "VOICE", "DOC", "POLL"
    val mediaUrl: String = "",
    val voiceDurationSeconds: Int = 0,
    val replyToText: String = "",
    val replyToSender: String = "",
    val reactions: String = "", // e.g., "❤️,👍"
    val isStarred: Boolean = false,
    val isEdited: Boolean = false,
    val isPinned: Boolean = false
)

@Entity(tableName = "call_logs")
data class CallLog(
    @PrimaryKey val id: String,
    val contactName: String,
    val contactAvatar: String = "",
    val isVideo: Boolean = false,
    val isOutgoing: Boolean = true,
    val isMissed: Boolean = false,
    val timestamp: Long = System.currentTimeMillis(),
    val durationText: String = "2m 14s"
)

@Entity(tableName = "status_updates")
data class StatusUpdate(
    @PrimaryKey val id: String,
    val userId: String,
    val userName: String,
    val content: String,
    val mediaType: String = "TEXT", // "TEXT", "IMAGE"
    val timestamp: Long = System.currentTimeMillis(),
    val bgHex: String = "#E53935", // Brand red or dark
    val viewed: Boolean = false
)

@Entity(tableName = "communities")
data class Community(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val memberCount: Int,
    val isBroadcastChannel: Boolean = false,
    val isSubscribed: Boolean = true,
    val latestAnnouncement: String = ""
)

@Entity(tableName = "ai_messages")
data class AiMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val prompt: String,
    val response: String,
    val timestamp: Long = System.currentTimeMillis(),
    val category: String = "General" // "General", "Coding", "Startup", "Summary"
)
