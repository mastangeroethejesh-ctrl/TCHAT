package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.ui.TchatViewModel
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.MainScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TchatDarkBg

class MainActivity : ComponentActivity() {
  private val viewModel: TchatViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        val showSplash by viewModel.showSplashScreen.collectAsState()
        val isLoggedIn by viewModel.isLoggedIn.collectAsState()

        Surface(
          modifier = Modifier.fillMaxSize(),
          color = TchatDarkBg
        ) {
          Crossfade(targetState = showSplash, label = "splashCrossfade") { isSplash ->
            if (isSplash) {
              SplashScreen()
            } else {
              Crossfade(targetState = isLoggedIn, label = "authCrossfade") { loggedIn ->
                if (!loggedIn) {
                  AuthScreen(viewModel = viewModel)
                } else {
                  MainScreen(viewModel = viewModel)
                }
              }
            }
          }
        }
      }
    }
  }
}

