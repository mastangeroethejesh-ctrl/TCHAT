package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CallLog
import com.example.ui.TchatViewModel
import com.example.ui.components.TchatAvatar
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CallsScreen(
    viewModel: TchatViewModel,
    modifier: Modifier = Modifier
) {
    val callLogs by viewModel.callLogs.collectAsState()
    val conversations by viewModel.activeConversations.collectAsState()
    var showStartCallDialog by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = TchatDarkBg,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Calls",
                            color = TchatWhite,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "WebRTC HD Audio & Video",
                            color = TchatYellow,
                            fontSize = 11.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = TchatSurfaceDark)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showStartCallDialog = true },
                containerColor = TchatRed,
                contentColor = TchatWhite,
                shape = CircleShape
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "New Call",
                    tint = TchatWhite
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (callLogs.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = null,
                        tint = TchatYellow.copy(alpha = 0.5f),
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No recent calls",
                        color = TchatWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "All voice and video calls use secure WebRTC low-latency streaming.",
                        color = TchatTextSecondary,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    items(callLogs, key = { it.id }) { log ->
                        CallLogRow(
                            callLog = log,
                            onAudioCall = { viewModel.startCall(log.contactName, isVideo = false) },
                            onVideoCall = { viewModel.startCall(log.contactName, isVideo = true) }
                        )
                    }
                }
            }
        }
    }

    // Start New Call Dialog
    if (showStartCallDialog) {
        AlertDialog(
            onDismissRequest = { showStartCallDialog = false },
            containerColor = TchatSurfaceDark,
            title = {
                Text(text = "Start WebRTC Call", color = TchatWhite, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Select a contact or channel to begin a low-latency WebRTC session:",
                        color = TchatTextSecondary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    conversations.forEach { conv ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    showStartCallDialog = false
                                    viewModel.startCall(conv.name, isVideo = false)
                                }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TchatAvatar(name = conv.name, isGroup = conv.isGroup, size = 38.dp)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = conv.name,
                                color = TchatWhite,
                                fontSize = 14.sp,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = {
                                showStartCallDialog = false
                                viewModel.startCall(conv.name, isVideo = false)
                            }) {
                                Icon(Icons.Default.Call, contentDescription = "Audio", tint = TchatYellow)
                            }
                            IconButton(onClick = {
                                showStartCallDialog = false
                                viewModel.startCall(conv.name, isVideo = true)
                            }) {
                                Icon(Icons.Default.Videocam, contentDescription = "Video", tint = TchatRed)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showStartCallDialog = false }) {
                    Text("Close", color = TchatTextSecondary)
                }
            }
        )
    }
}

@Composable
fun CallLogRow(
    callLog: CallLog,
    onAudioCall: () -> Unit,
    onVideoCall: () -> Unit
) {
    val dateFormatted = remember(callLog.timestamp) {
        val sdf = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())
        sdf.format(Date(callLog.timestamp))
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TchatAvatar(name = callLog.contactName, size = 48.dp)

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = callLog.contactName,
                color = if (callLog.isMissed) TchatRed else TchatWhite,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(3.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (callLog.isOutgoing) Icons.Default.CallMade else Icons.Default.CallReceived,
                    contentDescription = null,
                    tint = if (callLog.isMissed) TchatRed else TchatYellow,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "$dateFormatted • ${callLog.durationText}",
                    color = TchatTextMuted,
                    fontSize = 12.sp
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            IconButton(onClick = onAudioCall) {
                Icon(
                    imageVector = Icons.Default.Call,
                    contentDescription = "Voice Call",
                    tint = TchatYellow
                )
            }
            IconButton(onClick = onVideoCall) {
                Icon(
                    imageVector = Icons.Default.Videocam,
                    contentDescription = "Video Call",
                    tint = TchatRed
                )
            }
        }
    }
}
