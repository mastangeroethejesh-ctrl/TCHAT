package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.CallState
import com.example.ui.TchatViewModel
import com.example.ui.components.TchatAvatar
import com.example.ui.components.TchatVoiceWaveform
import com.example.ui.theme.*

@Composable
fun ActiveCallScreen(
    callState: CallState,
    viewModel: TchatViewModel,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "callRadar")
    val pulseRadius by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.4f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseRadius"
    )

    val radarAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "radarAlpha"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        TchatSurfaceDark,
                        TchatDarkBg,
                        Color.Black
                    )
                )
            )
    ) {
        // Video Preview Background Simulation
        if (callState.isVideo && callState.isCameraOn) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.6f))
            ) {
                // Video stream simulated indicator
                Box(
                    modifier = Modifier
                        .padding(16.dp)
                        .align(Alignment.TopEnd)
                        .size(width = 110.dp, height = 150.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(TchatSurfaceElevated)
                        .padding(2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Videocam, contentDescription = null, tint = TchatYellow)
                        Text("You (HD)", color = TchatWhite, fontSize = 11.sp)
                    }
                }
            }
        }

        // Central Caller Info & Radar Waveform
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 80.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Radar Circles Canvas behind Avatar
            Box(
                modifier = Modifier.size(180.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val radius = (size.minDimension / 2) * pulseRadius
                    drawCircle(
                        color = if (callState.isVideo) TchatYellow.copy(alpha = radarAlpha) else TchatRed.copy(alpha = radarAlpha),
                        radius = radius,
                        center = Offset(size.width / 2, size.height / 2),
                        style = Stroke(width = 3.dp.toPx())
                    )
                }

                TchatAvatar(
                    name = callState.contactName,
                    size = 96.dp
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = callState.contactName,
                color = TchatWhite,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = callState.status,
                color = if (callState.status.contains("Connected")) TchatYellow else TchatWhite.copy(alpha = 0.8f),
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium
            )

            if (callState.status.contains("Connected")) {
                val sec = callState.durationSeconds
                val timerText = String.format("%02d:%02d", sec / 60, sec % 60)
                Text(
                    text = timerText,
                    color = TchatTextSecondary,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Active Audio Waveform visualization
                TchatVoiceWaveform(
                    isPlaying = true,
                    progress = 0.7f,
                    modifier = Modifier.padding(horizontal = 32.dp)
                )
            }
        }

        // Bottom Call Control Bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(bottom = 48.dp, start = 24.dp, end = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Mute Microphone
                IconButton(
                    onClick = { viewModel.toggleCallMute() },
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(if (callState.isMuted) TchatYellow else TchatSurfaceElevated)
                ) {
                    Icon(
                        imageVector = if (callState.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Mute",
                        tint = if (callState.isMuted) TchatBlack else TchatWhite
                    )
                }

                // Speakerphone Toggle
                IconButton(
                    onClick = { viewModel.toggleCallSpeaker() },
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(if (callState.isSpeakerOn) TchatYellow else TchatSurfaceElevated)
                ) {
                    Icon(
                        imageVector = if (callState.isSpeakerOn) Icons.Default.VolumeUp else Icons.Default.VolumeDown,
                        contentDescription = "Speaker",
                        tint = if (callState.isSpeakerOn) TchatBlack else TchatWhite
                    )
                }

                // Video Camera Toggle
                if (callState.isVideo) {
                    IconButton(
                        onClick = { viewModel.toggleCallCamera() },
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(if (!callState.isCameraOn) TchatRed else TchatSurfaceElevated)
                    ) {
                        Icon(
                            imageVector = if (callState.isCameraOn) Icons.Default.Videocam else Icons.Default.VideocamOff,
                            contentDescription = "Camera",
                            tint = TchatWhite
                        )
                    }
                }

                // End Call Button (Tchat Red)
                IconButton(
                    onClick = { viewModel.endCall() },
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(TchatRed)
                ) {
                    Icon(
                        imageVector = Icons.Default.CallEnd,
                        contentDescription = "End Call",
                        tint = TchatWhite,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }
    }
}
