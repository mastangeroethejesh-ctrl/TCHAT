package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Conversation
import com.example.ui.TchatViewModel
import com.example.ui.components.MessageStatusIndicator
import com.example.ui.components.TchatAvatar
import com.example.ui.components.TchatLogo
import com.example.ui.components.TchatUnreadBadge
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatsScreen(
    viewModel: TchatViewModel,
    modifier: Modifier = Modifier
) {
    val conversations by viewModel.activeConversations.collectAsState()
    val archivedConversations by viewModel.archivedConversations.collectAsState()
    var isSearchActive by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var showArchivedView by remember { mutableStateOf(false) }
    var showNewChatDialog by remember { mutableStateOf(false) }
    var selectedConvForOptions by remember { mutableStateOf<Conversation?>(null) }

    val displayList = remember(conversations, archivedConversations, showArchivedView, searchQuery) {
        val base = if (showArchivedView) archivedConversations else conversations
        if (searchQuery.isBlank()) {
            base
        } else {
            base.filter {
                it.name.contains(searchQuery, ignoreCase = true) ||
                        it.lastMessage.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = TchatDarkBg,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TchatSurfaceDark)
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        TchatLogo(size = 36.dp, animated = false)
                        Column {
                            Text(
                                text = if (showArchivedView) "Archived Chats" else "Tchat",
                                color = TchatWhite,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Techstarc.chat • By Thejesh",
                                color = TchatYellow,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(onClick = { isSearchActive = !isSearchActive }) {
                            Icon(
                                imageVector = if (isSearchActive) Icons.Default.Close else Icons.Default.Search,
                                contentDescription = "Search",
                                tint = TchatYellow
                            )
                        }
                        if (archivedConversations.isNotEmpty()) {
                            IconButton(onClick = { showArchivedView = !showArchivedView }) {
                                Icon(
                                    imageVector = if (showArchivedView) Icons.Default.Chat else Icons.Default.Archive,
                                    contentDescription = "Archived",
                                    tint = if (showArchivedView) TchatRed else TchatWhite
                                )
                            }
                        }
                    }
                }

                // Search Bar Expandable
                AnimatedVisibility(visible = isSearchActive) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search chats or messages...", color = TchatTextMuted, fontSize = 13.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TchatWhite,
                            unfocusedTextColor = TchatWhite,
                            focusedBorderColor = TchatYellow,
                            unfocusedBorderColor = TchatBorder,
                            focusedContainerColor = TchatDarkBg,
                            unfocusedContainerColor = TchatDarkBg
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }
        },
        floatingActionButton = {
            if (!showArchivedView) {
                FloatingActionButton(
                    onClick = { showNewChatDialog = true },
                    containerColor = TchatRed,
                    contentColor = TchatWhite,
                    shape = CircleShape
                ) {
                    Icon(
                        imageVector = Icons.Default.ChatBubble,
                        contentDescription = "New Chat",
                        tint = TchatWhite
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (displayList.isEmpty()) {
                // Empty state
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Forum,
                        contentDescription = null,
                        tint = TchatYellow.copy(alpha = 0.6f),
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = if (showArchivedView) "No archived chats" else "No conversations yet",
                        color = TchatWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Tap the message button to initiate a new real-time conversation on Tchat.",
                        color = TchatTextSecondary,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(vertical = 6.dp)
                ) {
                    items(displayList, key = { it.id }) { conv ->
                        ChatItemRow(
                            conversation = conv,
                            onClick = { viewModel.openConversation(conv.id) },
                            onLongClick = { selectedConvForOptions = conv }
                        )
                    }
                }
            }
        }
    }

    // Chat Options Bottom Sheet / Dialog
    selectedConvForOptions?.let { conv ->
        AlertDialog(
            onDismissRequest = { selectedConvForOptions = null },
            containerColor = TchatSurfaceDark,
            title = {
                Text(text = conv.name, color = TchatWhite, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(
                        onClick = {
                            viewModel.togglePinChat(conv.id)
                            selectedConvForOptions = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.PushPin, contentDescription = null, tint = TchatYellow)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (conv.isPinned) "Unpin Chat" else "Pin to Top",
                            color = TchatWhite,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    TextButton(
                        onClick = {
                            viewModel.toggleMuteChat(conv.id)
                            selectedConvForOptions = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.NotificationsOff, contentDescription = null, tint = TchatYellow)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (conv.isMuted) "Unmute Notifications" else "Mute Notifications",
                            color = TchatWhite,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    TextButton(
                        onClick = {
                            viewModel.toggleArchiveChat(conv.id)
                            selectedConvForOptions = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Archive, contentDescription = null, tint = TchatYellow)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (conv.isArchived) "Unarchive Chat" else "Archive Chat",
                            color = TchatWhite,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    TextButton(
                        onClick = {
                            viewModel.deleteChat(conv.id)
                            selectedConvForOptions = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, tint = TchatRed)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Delete Chat", color = TchatRed, modifier = Modifier.weight(1f))
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedConvForOptions = null }) {
                    Text("Close", color = TchatTextSecondary)
                }
            }
        )
    }

    // New Chat / Group Creation Dialog
    if (showNewChatDialog) {
        NewChatDialog(
            onDismiss = { showNewChatDialog = false },
            onCreate = { name, isGroup, initialMessage ->
                viewModel.createChat(name, isGroup, initialMessage)
                showNewChatDialog = false
            }
        )
    }
}

@Composable
fun ChatItemRow(
    conversation: Conversation,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val timeFormatted = remember(conversation.lastMessageTime) {
        val sdf = SimpleDateFormat("h:mm a", Locale.getDefault())
        sdf.format(Date(conversation.lastMessageTime))
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Avatar with Online dot
        TchatAvatar(
            name = conversation.name,
            isOnline = conversation.isOnline,
            isGroup = conversation.isGroup,
            size = 52.dp
        )

        Spacer(modifier = Modifier.width(14.dp))

        // Center: Name and last message / typing indicator
        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = conversation.name,
                        color = TchatWhite,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (conversation.isPinned) {
                        Icon(
                            imageVector = Icons.Default.PushPin,
                            contentDescription = "Pinned",
                            tint = TchatYellow,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }

                Text(
                    text = timeFormatted,
                    color = if (conversation.unreadCount > 0) TchatYellow else TchatTextMuted,
                    fontSize = 11.sp,
                    fontWeight = if (conversation.unreadCount > 0) FontWeight.Bold else FontWeight.Normal
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (conversation.typingStatus.isNotEmpty()) {
                    Text(
                        text = "typing...",
                        color = TchatYellow,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                } else {
                    Text(
                        text = conversation.lastMessage,
                        color = if (conversation.unreadCount > 0) TchatWhite else TchatTextSecondary,
                        fontSize = 13.sp,
                        fontWeight = if (conversation.unreadCount > 0) FontWeight.Medium else FontWeight.Normal,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (conversation.isMuted) {
                        Icon(
                            imageVector = Icons.Default.VolumeMute,
                            contentDescription = "Muted",
                            tint = TchatTextMuted,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    if (conversation.unreadCount > 0) {
                        TchatUnreadBadge(count = conversation.unreadCount)
                    }
                }
            }
        }
    }
}

@Composable
fun NewChatDialog(
    onDismiss: () -> Unit,
    onCreate: (name: String, isGroup: Boolean, initialMessage: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var isGroup by remember { mutableStateOf(false) }
    var initialMessage by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = TchatSurfaceDark,
        title = {
            Text(text = if (isGroup) "Create New Group" else "Start New Conversation", color = TchatWhite, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // Group toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Group Chat", color = TchatWhite, fontSize = 14.sp)
                    Switch(
                        checked = isGroup,
                        onCheckedChange = { isGroup = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = TchatWhite,
                            checkedTrackColor = TchatRed,
                            uncheckedTrackColor = TchatSurfaceElevated
                        )
                    )
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(if (isGroup) "Group Name" else "Contact Name", color = TchatTextSecondary) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TchatWhite,
                        unfocusedTextColor = TchatWhite,
                        focusedBorderColor = TchatYellow,
                        unfocusedBorderColor = TchatBorder
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = initialMessage,
                    onValueChange = { initialMessage = it },
                    label = { Text("Initial message (optional)", color = TchatTextSecondary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TchatWhite,
                        unfocusedTextColor = TchatWhite,
                        focusedBorderColor = TchatYellow,
                        unfocusedBorderColor = TchatBorder
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onCreate(name.trim(), isGroup, initialMessage.trim())
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = TchatRed)
            ) {
                Text(if (isGroup) "Create Group" else "Start Chat", color = TchatWhite)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TchatTextSecondary)
            }
        }
    )
}
