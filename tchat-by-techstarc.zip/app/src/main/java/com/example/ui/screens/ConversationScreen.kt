package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Conversation
import com.example.model.Message
import com.example.ui.TchatViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConversationScreen(
    conversationId: String,
    viewModel: TchatViewModel,
    modifier: Modifier = Modifier
) {
    val conversations by viewModel.activeConversations.collectAsState()
    val currentConv = conversations.find { it.id == conversationId }
    val messages by viewModel.currentMessages.collectAsState()
    val isRecording by viewModel.isRecordingVoice.collectAsState()
    val recordingSec by viewModel.voiceRecordingSeconds.collectAsState()

    var textInput by remember { mutableStateOf("") }
    var replyingToMessage by remember { mutableStateOf<Message?>(null) }
    var selectedMessageForOptions by remember { mutableStateOf<Message?>(null) }
    var showAttachmentMenu by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    // Auto-scroll to bottom on new message
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = TchatDarkBg,
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        TchatAvatar(
                            name = currentConv?.name ?: "Chat",
                            isOnline = currentConv?.isOnline ?: false,
                            isGroup = currentConv?.isGroup ?: false,
                            size = 38.dp
                        )
                        Column {
                            Text(
                                text = currentConv?.name ?: "Chat",
                                color = TchatWhite,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = if (currentConv?.typingStatus?.isNotEmpty() == true) {
                                    "typing..."
                                } else if (currentConv?.isOnline == true) {
                                    "online"
                                } else {
                                    "last seen recently"
                                },
                                color = if (currentConv?.isOnline == true || currentConv?.typingStatus?.isNotEmpty() == true) TchatYellow else TchatTextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.closeConversation() }) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = TchatWhite
                        )
                    }
                },
                actions = {
                    // Voice Call Button
                    IconButton(onClick = {
                        viewModel.startCall(currentConv?.name ?: "Contact", isVideo = false)
                    }) {
                        Icon(
                            imageVector = Icons.Default.Call,
                            contentDescription = "Voice Call",
                            tint = TchatYellow
                        )
                    }
                    // Video Call Button
                    IconButton(onClick = {
                        viewModel.startCall(currentConv?.name ?: "Contact", isVideo = true)
                    }) {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = "Video Call",
                            tint = TchatYellow
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = TchatSurfaceDark)
            )
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TchatSurfaceDark)
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                // Quoted Reply preview banner
                replyingToMessage?.let { replyMsg ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(TchatSurfaceElevated)
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(28.dp)
                                .background(TchatYellow)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = replyMsg.senderName,
                                color = TchatYellow,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = replyMsg.text,
                                color = TchatWhite,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(
                            onClick = { replyingToMessage = null },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Cancel reply", tint = TchatWhite)
                        }
                    }
                }

                // Input Field / Voice Recording Row
                if (isRecording) {
                    // Active Recording Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(TchatRed)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Recording: ${recordingSec / 60}:${String.format("%02d", recordingSec % 60)}",
                                color = TchatWhite,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            IconButton(onClick = { viewModel.cancelVoiceRecording() }) {
                                Icon(Icons.Default.Delete, contentDescription = "Cancel", tint = TchatRed)
                            }
                            IconButton(
                                onClick = { viewModel.stopAndSendVoiceRecording() },
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(TchatYellow)
                            ) {
                                Icon(Icons.Default.Send, contentDescription = "Send", tint = TchatBlack)
                            }
                        }
                    }
                } else {
                    // Standard Text & Attachments Input Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { showAttachmentMenu = !showAttachmentMenu }) {
                            Icon(
                                imageVector = Icons.Default.AttachFile,
                                contentDescription = "Attach",
                                tint = TchatYellow
                            )
                        }

                        OutlinedTextField(
                            value = textInput,
                            onValueChange = { textInput = it },
                            placeholder = { Text("Message...", color = TchatTextMuted, fontSize = 14.sp) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TchatWhite,
                                unfocusedTextColor = TchatWhite,
                                focusedBorderColor = TchatYellow,
                                unfocusedBorderColor = TchatBorder,
                                focusedContainerColor = TchatDarkBg,
                                unfocusedContainerColor = TchatDarkBg
                            ),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.weight(1f),
                            maxLines = 4
                        )

                        Spacer(modifier = Modifier.width(6.dp))

                        if (textInput.isNotBlank()) {
                            // Send Text Message
                            IconButton(
                                onClick = {
                                    val toSend = textInput.trim()
                                    val rep = replyingToMessage
                                    textInput = ""
                                    replyingToMessage = null
                                    viewModel.sendMessage(
                                        text = toSend,
                                        replyToText = rep?.text ?: "",
                                        replyToSender = rep?.senderName ?: ""
                                    )
                                },
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(TchatRed)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Send,
                                    contentDescription = "Send",
                                    tint = TchatWhite
                                )
                            }
                        } else {
                            // Voice Note Recorder Button
                            IconButton(
                                onClick = { viewModel.startVoiceRecording() },
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(TchatYellow)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "Record Voice Note",
                                    tint = TchatBlack
                                )
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    MessageBubble(
                        message = msg,
                        onLongClick = { selectedMessageForOptions = msg },
                        onReply = { replyingToMessage = msg },
                        onReact = { reaction -> viewModel.addReaction(msg.id, reaction) }
                    )
                }

                // Show contact typing animation
                if (currentConv?.typingStatus?.isNotEmpty() == true) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Start
                        ) {
                            TchatTypingIndicator()
                        }
                    }
                }
            }

            // Attachment Options Modal Sheet
            if (showAttachmentMenu) {
                Card(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 16.dp, bottom = 8.dp)
                        .width(220.dp),
                    colors = CardDefaults.cardColors(containerColor = TchatSurfaceElevated),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        AttachmentItem(
                            icon = Icons.Default.PhotoCamera,
                            label = "Photo & Video",
                            color = TchatYellow,
                            onClick = {
                                showAttachmentMenu = false
                                viewModel.sendMessage("📷 Shared photo", type = "IMAGE")
                            }
                        )
                        AttachmentItem(
                            icon = Icons.Default.Description,
                            label = "Document",
                            color = TchatWhite,
                            onClick = {
                                showAttachmentMenu = false
                                viewModel.sendMessage("📄 Techstarc_Document.pdf", type = "DOC")
                            }
                        )
                        AttachmentItem(
                            icon = Icons.Default.Poll,
                            label = "Team Poll",
                            color = TchatRed,
                            onClick = {
                                showAttachmentMenu = false
                                viewModel.sendMessage("📊 Poll: Which Tchat feature do you like most?", type = "POLL")
                            }
                        )
                    }
                }
            }
        }
    }

    // Message Long-Press Options Dialog
    selectedMessageForOptions?.let { msg ->
        AlertDialog(
            onDismissRequest = { selectedMessageForOptions = null },
            containerColor = TchatSurfaceDark,
            title = {
                Text(text = "Message Actions", color = TchatWhite, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Quick Reaction Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf("❤️", "👍", "🔥", "😂", "👏").forEach { emoji ->
                            Text(
                                text = emoji,
                                fontSize = 24.sp,
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .clickable {
                                        viewModel.addReaction(msg.id, emoji)
                                        selectedMessageForOptions = null
                                    }
                                    .padding(4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    TextButton(
                        onClick = {
                            replyingToMessage = msg
                            selectedMessageForOptions = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Reply, contentDescription = null, tint = TchatYellow)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Reply", color = TchatWhite, modifier = Modifier.weight(1f))
                    }

                    TextButton(
                        onClick = {
                            viewModel.toggleStar(msg.id)
                            selectedMessageForOptions = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = if (msg.isStarred) Icons.Default.StarBorder else Icons.Default.Star,
                            contentDescription = null,
                            tint = TchatYellow
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(if (msg.isStarred) "Unstar" else "Star Message", color = TchatWhite, modifier = Modifier.weight(1f))
                    }

                    TextButton(
                        onClick = {
                            viewModel.deleteMessage(msg.id)
                            selectedMessageForOptions = null
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, tint = TchatRed)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Delete Message", color = TchatRed, modifier = Modifier.weight(1f))
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedMessageForOptions = null }) {
                    Text("Close", color = TchatTextSecondary)
                }
            }
        )
    }
}

@Composable
fun AttachmentItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(12.dp))
        Text(text = label, color = TchatWhite, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun MessageBubble(
    message: Message,
    onLongClick: () -> Unit,
    onReply: () -> Unit,
    onReact: (String) -> Unit
) {
    val isMe = message.isFromMe
    val bubbleColor = if (isMe) TchatRed else TchatSurfaceElevated
    val timeFormatted = remember(message.timestamp) {
        val sdf = SimpleDateFormat("h:mm a", Locale.getDefault())
        sdf.format(Date(message.timestamp))
    }

    var isVoicePlaying by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isMe) Arrangement.End else Arrangement.Start
    ) {
        Column(
            horizontalAlignment = if (isMe) Alignment.End else Alignment.Start,
            modifier = Modifier.widthIn(max = 300.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(
                        RoundedCornerShape(
                            topStart = 16.dp,
                            topEnd = 16.dp,
                            bottomStart = if (isMe) 16.dp else 4.dp,
                            bottomEnd = if (isMe) 4.dp else 16.dp
                        )
                    )
                    .background(bubbleColor)
                    .clickable(onClick = onLongClick)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Column {
                    // Quoted reply content
                    if (message.replyToText.isNotEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 6.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color.Black.copy(alpha = 0.2f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Column {
                                Text(
                                    text = message.replyToSender,
                                    color = TchatYellow,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = message.replyToText,
                                    color = TchatWhite.copy(alpha = 0.85f),
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    // Message Content based on type
                    when (message.type) {
                        "VOICE" -> {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                IconButton(
                                    onClick = { isVoicePlaying = !isVoicePlaying },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(if (isMe) TchatYellow else TchatRed)
                                ) {
                                    Icon(
                                        imageVector = if (isVoicePlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Play",
                                        tint = if (isMe) TchatBlack else TchatWhite,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                TchatVoiceWaveform(
                                    isPlaying = isVoicePlaying,
                                    progress = if (isVoicePlaying) 0.6f else 0.2f
                                )
                                Text(
                                    text = "${message.voiceDurationSeconds}s",
                                    color = TchatWhite,
                                    fontSize = 11.sp
                                )
                            }
                        }
                        "IMAGE" -> {
                            Column {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(140.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color.Black.copy(alpha = 0.3f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Image,
                                        contentDescription = null,
                                        tint = TchatYellow,
                                        modifier = Modifier.size(48.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = message.text,
                                    color = TchatWhite,
                                    fontSize = 14.sp
                                )
                            }
                        }
                        else -> {
                            Text(
                                text = message.text,
                                color = TchatWhite,
                                fontSize = 14.sp,
                                lineHeight = 20.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(3.dp))

                    // Timestamp and Delivery Tick
                    Row(
                        modifier = Modifier.align(Alignment.End),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (message.isStarred) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "Starred",
                                tint = TchatYellow,
                                modifier = Modifier.size(11.dp)
                            )
                        }
                        Text(
                            text = timeFormatted,
                            color = TchatWhite.copy(alpha = 0.65f),
                            fontSize = 10.sp
                        )
                        if (isMe) {
                            MessageStatusIndicator(status = message.status)
                        }
                    }
                }
            }

            // Reactions badge
            if (message.reactions.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .offset(y = (-8).dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(TchatSurfaceDark)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(text = message.reactions, fontSize = 12.sp)
                }
            }
        }
    }
}
