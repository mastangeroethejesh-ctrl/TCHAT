package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = TchatRed,
    onPrimary = TchatWhite,
    primaryContainer = TchatRed.copy(alpha = 0.2f),
    onPrimaryContainer = TchatYellow,
    secondary = TchatYellow,
    onSecondary = TchatBlack,
    secondaryContainer = TchatYellow.copy(alpha = 0.2f),
    onSecondaryContainer = TchatWhite,
    tertiary = TchatWhite,
    onTertiary = TchatBlack,
    background = TchatDarkBg,
    onBackground = TchatWhite,
    surface = TchatSurfaceDark,
    onSurface = TchatWhite,
    surfaceVariant = TchatSurfaceElevated,
    onSurfaceVariant = TchatTextSecondary,
    outline = TchatBorder,
    error = TchatRed,
    onError = TchatWhite
)

private val LightColorScheme = lightColorScheme(
    primary = TchatRed,
    onPrimary = TchatWhite,
    primaryContainer = TchatRed.copy(alpha = 0.12f),
    onPrimaryContainer = TchatRed,
    secondary = TchatYellow,
    onSecondary = TchatBlack,
    secondaryContainer = TchatYellow.copy(alpha = 0.15f),
    onSecondaryContainer = TchatBlack,
    tertiary = TchatRed,
    onTertiary = TchatWhite,
    background = TchatLightBg,
    onBackground = TchatLightTextPrimary,
    surface = TchatLightSurface,
    onSurface = TchatLightTextPrimary,
    surfaceVariant = TchatLightSurfaceElevated,
    onSurfaceVariant = TchatLightTextSecondary,
    outline = TchatLightBorder,
    error = TchatRed,
    onError = TchatWhite
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to sleek cinematic dark theme for Tchat
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
