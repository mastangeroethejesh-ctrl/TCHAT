package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.StatusUpdate
import com.example.ui.TchatViewModel
import com.example.ui.components.TchatAvatar
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatusScreen(
    viewModel: TchatViewModel,
    modifier: Modifier = Modifier
) {
    val statuses by viewModel.statusUpdates.collectAsState()
    val viewingStatus by viewModel.viewingStatus.collectAsState()
    var showPostDialog by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = TchatDarkBg,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Updates & Status",
                            color = TchatWhite,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "24-Hour Ephemeral Stories",
                            color = TchatYellow,
                            fontSize = 11.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = TchatSurfaceDark)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showPostDialog = true },
                containerColor = TchatYellow,
                contentColor = TchatBlack,
                shape = CircleShape
            ) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = "Post Status",
                    tint = TchatBlack
                )
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // My Status Section
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(TchatSurfaceDark)
                        .clickable { showPostDialog = true }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.size(52.dp)) {
                        TchatAvatar(name = "My Status", size = 52.dp)
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .align(Alignment.BottomEnd)
                                .clip(CircleShape)
                                .background(TchatRed),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add",
                                tint = TchatWhite,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column {
                        Text(
                            text = "My Status",
                            color = TchatWhite,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Tap to add a 24-hour update",
                            color = TchatTextMuted,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // Recent Updates Header
            item {
                Text(
                    text = "RECENT UPDATES",
                    color = TchatYellow,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            // Status List
            items(statuses, key = { it.id }) { status ->
                StatusItemRow(
                    status = status,
                    onClick = { viewModel.openStatus(status) }
                )
            }
        }
    }

    // Fullscreen Status Story Viewer
    viewingStatus?.let { status ->
        StatusStoryViewer(
            status = status,
            onClose = { viewModel.closeStatus() },
            onReply = { replyText ->
                viewModel.sendMessage("Replying to status: $replyText")
                viewModel.closeStatus()
            }
        )
    }

    // Post New Status Dialog
    if (showPostDialog) {
        PostStatusDialog(
            onDismiss = { showPostDialog = false },
            onPost = { text, bgHex ->
                viewModel.postStatus(text, bgHex)
                showPostDialog = false
            }
        )
    }
}

@Composable
fun StatusItemRow(
    status: StatusUpdate,
    onClick: () -> Unit
) {
    val timeFormatted = remember(status.timestamp) {
        val sdf = SimpleDateFormat("h:mm a", Locale.getDefault())
        sdf.format(Date(status.timestamp))
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Status Ring (Yellow if unviewed, Red / Grey if viewed)
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .border(
                    width = 2.5.dp,
                    color = if (status.viewed) TchatTextMuted else TchatYellow,
                    shape = CircleShape
                )
                .padding(3.dp)
        ) {
            TchatAvatar(name = status.userName, size = 48.dp)
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = status.userName,
                color = TchatWhite,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "Today at $timeFormatted (Expires in 24h)",
                color = TchatTextMuted,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
fun StatusStoryViewer(
    status: StatusUpdate,
    onClose: () -> Unit,
    onReply: (String) -> Unit
) {
    val progress = remember { Animatable(0f) }
    var replyText by remember { mutableStateOf("") }

    LaunchedEffect(status.id) {
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 5000, easing = LinearEasing)
        )
        onClose()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                when (status.bgHex) {
                    "#E53935" -> Brush.verticalGradient(listOf(TchatRed, TchatDarkBg))
                    "#FFC107" -> Brush.verticalGradient(listOf(TchatYellow, TchatDarkBg))
                    else -> Brush.verticalGradient(listOf(TchatSurfaceDark, TchatBlack))
                }
            )
    ) {
        // Top Progress Bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 40.dp, start = 16.dp, end = 16.dp)
        ) {
            LinearProgressIndicator(
                progress = { progress.value },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = TchatYellow,
                trackColor = TchatWhite.copy(alpha = 0.3f)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TchatAvatar(name = status.userName, size = 36.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = status.userName,
                            color = TchatWhite,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "24h Ephemeral Status",
                            color = TchatWhite.copy(alpha = 0.7f),
                            fontSize = 11.sp
                        )
                    }
                }

                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TchatWhite)
                }
            }
        }

        // Story Center Content
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 32.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = status.content,
                color = TchatWhite,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 32.sp
            )
        }

        // Bottom Reply Field
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = replyText,
                onValueChange = { replyText = it },
                placeholder = { Text("Reply to status...", color = TchatTextMuted, fontSize = 13.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TchatWhite,
                    unfocusedTextColor = TchatWhite,
                    focusedBorderColor = TchatYellow,
                    unfocusedBorderColor = TchatBorder,
                    focusedContainerColor = TchatDarkBg,
                    unfocusedContainerColor = TchatDarkBg
                ),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.weight(1f)
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = {
                    if (replyText.isNotBlank()) {
                        onReply(replyText)
                    }
                },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(TchatRed)
            ) {
                Icon(Icons.Default.Send, contentDescription = "Send Reply", tint = TchatWhite)
            }
        }
    }
}

@Composable
fun PostStatusDialog(
    onDismiss: () -> Unit,
    onPost: (text: String, bgHex: String) -> Unit
) {
    var text by remember { mutableStateOf("") }
    var selectedBg by remember { mutableStateOf("#E53935") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = TchatSurfaceDark,
        title = {
            Text("Post 24-Hour Status", color = TchatWhite, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("What's on your mind?", color = TchatTextMuted) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TchatWhite,
                        unfocusedTextColor = TchatWhite,
                        focusedBorderColor = TchatYellow,
                        unfocusedBorderColor = TchatBorder
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3
                )

                Text("Background Color Palette:", color = TchatWhite, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    listOf("#E53935", "#FFC107", "#1E1E1E").forEach { hex ->
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(
                                    when (hex) {
                                        "#E53935" -> TchatRed
                                        "#FFC107" -> TchatYellow
                                        else -> TchatSurfaceElevated
                                    }
                                )
                                .clickable { selectedBg = hex }
                                .border(
                                    width = if (selectedBg == hex) 3.dp else 0.dp,
                                    color = TchatWhite,
                                    shape = CircleShape
                                )
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (text.isNotBlank()) {
                        onPost(text.trim(), selectedBg)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = TchatRed)
            ) {
                Text("Share to Status", color = TchatWhite)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TchatTextSecondary)
            }
        }
    )
}
