package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AiMessage
import com.example.ui.TchatViewModel
import com.example.ui.components.TchatLoadingSpinner
import com.example.ui.components.TchatLogo
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TechstarcAiScreen(
    viewModel: TchatViewModel,
    modifier: Modifier = Modifier
) {
    val aiMessages by viewModel.aiMessages.collectAsState()
    val isGenerating by viewModel.isAiGenerating.collectAsState()
    var promptInput by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("General") }

    val listState = rememberLazyListState()
    val clipboardManager = LocalClipboardManager.current

    val promptSuggestions = listOf(
        Pair("💻 Coding", "Review my Kotlin Jetpack Compose code for performance optimizations."),
        Pair("🚀 Startup", "Brainstorm 3 viral distribution strategies for Techstarc.chat."),
        Pair("📝 Summarize", "Summarize key architectural benefits of WebRTC over WebSocket audio streaming."),
        Pair("🌐 Translate", "Translate 'Welcome to the future of messaging' into Spanish, French, and Japanese."),
        Pair("📚 Homework", "Explain Dijkstra's algorithm and graph shortest path clearly with an example.")
    )

    LaunchedEffect(aiMessages.size) {
        if (aiMessages.isNotEmpty()) {
            listState.animateScrollToItem(aiMessages.size - 1)
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = TchatDarkBg,
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        TchatLogo(size = 36.dp, animated = true)
                        Column {
                            Text(
                                text = "Techstarc AI",
                                color = TchatWhite,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Powered by Google Gemini",
                                color = TchatYellow,
                                fontSize = 11.sp
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { /* Info */ }) {
                        Icon(Icons.Default.Info, contentDescription = "AI Info", tint = TchatYellow)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = TchatSurfaceDark)
            )
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TchatSurfaceDark)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                // Category Shortcut Chips
                LazyRow(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(promptSuggestions) { (cat, samplePrompt) ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (selectedCategory == cat) TchatRed else TchatSurfaceElevated)
                                .clickable {
                                    selectedCategory = cat
                                    promptInput = samplePrompt
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = cat,
                                color = TchatWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                // Input Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = promptInput,
                        onValueChange = { promptInput = it },
                        placeholder = { Text("Ask Techstarc AI anything...", color = TchatTextMuted, fontSize = 13.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TchatWhite,
                            unfocusedTextColor = TchatWhite,
                            focusedBorderColor = TchatYellow,
                            unfocusedBorderColor = TchatBorder,
                            focusedContainerColor = TchatDarkBg,
                            unfocusedContainerColor = TchatDarkBg
                        ),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.weight(1f),
                        maxLines = 3
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    if (isGenerating) {
                        TchatLoadingSpinner(size = 36.dp, strokeWidth = 3.dp)
                    } else {
                        IconButton(
                            onClick = {
                                if (promptInput.isNotBlank()) {
                                    val q = promptInput.trim()
                                    val cat = selectedCategory
                                    promptInput = ""
                                    viewModel.askTechstarcAi(q, cat)
                                }
                            },
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(TchatRed)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Send", tint = TchatWhite)
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Inaccuracy Notice Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TchatSurfaceElevated)
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = TchatYellow,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Techstarc AI can make mistakes. Verify important facts.",
                        color = TchatTextSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(aiMessages, key = { it.id }) { msg ->
                    AiConversationItem(
                        item = msg,
                        onCopy = { clipboardManager.setText(AnnotatedString(msg.response)) }
                    )
                }

                if (isGenerating) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Start,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(TchatSurfaceElevated)
                                    .padding(12.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    TchatLoadingSpinner(size = 20.dp, strokeWidth = 2.5.dp)
                                    Text(
                                        text = "Techstarc AI is generating response...",
                                        color = TchatYellow,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AiConversationItem(
    item: AiMessage,
    onCopy: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // User Question Bubble (Right aligned)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Box(
                modifier = Modifier
                    .widthIn(max = 280.dp)
                    .clip(
                        RoundedCornerShape(
                            topStart = 16.dp,
                            topEnd = 16.dp,
                            bottomStart = 16.dp,
                            bottomEnd = 4.dp
                        )
                    )
                    .background(TchatRed)
                    .padding(12.dp)
            ) {
                Text(
                    text = item.prompt,
                    color = TchatWhite,
                    fontSize = 14.sp
                )
            }
        }

        // Techstarc AI Response Bubble (Left aligned)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Start
        ) {
            Box(
                modifier = Modifier
                    .widthIn(max = 330.dp)
                    .clip(
                        RoundedCornerShape(
                            topStart = 16.dp,
                            topEnd = 16.dp,
                            bottomStart = 4.dp,
                            bottomEnd = 16.dp
                        )
                    )
                    .background(TchatSurfaceDark)
                    .padding(14.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = TchatYellow, modifier = Modifier.size(16.dp))
                            Text(
                                text = "Techstarc AI",
                                color = TchatYellow,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        IconButton(onClick = onCopy, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = TchatTextMuted, modifier = Modifier.size(15.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = item.response,
                        color = TchatWhite,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                }
            }
        }
    }
}
