package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Community
import com.example.ui.TchatViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommunitiesScreen(
    viewModel: TchatViewModel,
    modifier: Modifier = Modifier
) {
    val communities by viewModel.communities.collectAsState()
    var showCreateDialog by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = TchatDarkBg,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Communities & Channels",
                            color = TchatWhite,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Techstarc Global Network",
                            color = TchatYellow,
                            fontSize = 11.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = TchatSurfaceDark)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                containerColor = TchatRed,
                contentColor = TchatWhite,
                shape = CircleShape
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Create Community",
                    tint = TchatWhite
                )
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Spotlight Banner
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = TchatSurfaceDark),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Groups, contentDescription = null, tint = TchatYellow, modifier = Modifier.size(28.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Techstarc Ecosystem",
                                color = TchatWhite,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Connect with engineers, innovators, and founders building with Techstarc.chat. Access official broadcasts and specialized channels.",
                            color = TchatTextSecondary,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            items(communities, key = { it.id }) { community ->
                CommunityCard(
                    community = community,
                    onToggleSubscription = { viewModel.toggleCommunitySubscription(community.id) },
                    onOpen = {
                        viewModel.createChat(community.name, isGroup = true, initialMessage = "Joined ${community.name}")
                    }
                )
            }
        }
    }

    if (showCreateDialog) {
        CreateCommunityDialog(
            onDismiss = { showCreateDialog = false },
            onCreate = { name, desc, isBroadcast ->
                viewModel.createChat(name, isGroup = true, initialMessage = desc)
                showCreateDialog = false
            }
        )
    }
}

@Composable
fun CommunityCard(
    community: Community,
    onToggleSubscription: () -> Unit,
    onOpen: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen),
        colors = CardDefaults.cardColors(containerColor = TchatSurfaceElevated),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(if (community.isBroadcastChannel) TchatRed else TchatSurfaceDark),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (community.isBroadcastChannel) Icons.Default.Campaign else Icons.Default.Hub,
                            contentDescription = null,
                            tint = if (community.isBroadcastChannel) TchatWhite else TchatYellow,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column {
                        Text(
                            text = community.name,
                            color = TchatWhite,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${community.memberCount} members • ${if (community.isBroadcastChannel) "Broadcast Channel" else "Discussion Group"}",
                            color = TchatYellow,
                            fontSize = 11.sp
                        )
                    }
                }

                Button(
                    onClick = onToggleSubscription,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (community.isSubscribed) TchatSurfaceDark else TchatRed
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Text(
                        text = if (community.isSubscribed) "Joined" else "Join",
                        color = if (community.isSubscribed) TchatYellow else TchatWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = community.description,
                color = TchatTextSecondary,
                fontSize = 13.sp
            )

            if (community.latestAnnouncement.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(TchatSurfaceDark)
                        .padding(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(
                            imageVector = Icons.Default.Announcement,
                            contentDescription = null,
                            tint = TchatYellow,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = community.latestAnnouncement,
                            color = TchatWhite,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CreateCommunityDialog(
    onDismiss: () -> Unit,
    onCreate: (name: String, desc: String, isBroadcast: Boolean) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var isBroadcast by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = TchatSurfaceDark,
        title = {
            Text("Create Community or Channel", color = TchatWhite, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Community Name", color = TchatTextSecondary) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TchatWhite,
                        unfocusedTextColor = TchatWhite,
                        focusedBorderColor = TchatYellow,
                        unfocusedBorderColor = TchatBorder
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("Description & Purpose", color = TchatTextSecondary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TchatWhite,
                        unfocusedTextColor = TchatWhite,
                        focusedBorderColor = TchatYellow,
                        unfocusedBorderColor = TchatBorder
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Broadcast Channel (Announcements only)", color = TchatWhite, fontSize = 13.sp)
                    Switch(
                        checked = isBroadcast,
                        onCheckedChange = { isBroadcast = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = TchatWhite,
                            checkedTrackColor = TchatRed,
                            uncheckedTrackColor = TchatSurfaceElevated
                        )
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onCreate(name.trim(), desc.trim(), isBroadcast)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = TchatRed)
            ) {
                Text("Create", color = TchatWhite)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TchatTextSecondary)
            }
        }
    )
}
