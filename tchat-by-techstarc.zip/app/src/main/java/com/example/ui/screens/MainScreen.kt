package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainTab
import com.example.ui.TchatViewModel
import com.example.ui.theme.*

@Composable
fun MainScreen(
    viewModel: TchatViewModel,
    modifier: Modifier = Modifier
) {
    val currentTab by viewModel.currentTab.collectAsState()
    val activeConvId by viewModel.activeConversationId.collectAsState()
    val callState by viewModel.callState.collectAsState()
    val conversations by viewModel.activeConversations.collectAsState()
    val totalUnread = remember(conversations) { conversations.sumOf { it.unreadCount } }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val isWideScreen = maxWidth >= 720.dp

        if (callState.isActive) {
            // Fullscreen active WebRTC call screen overlay
            ActiveCallScreen(
                callState = callState,
                viewModel = viewModel
            )
        } else if (activeConvId != null) {
            // Active Conversation screen
            ConversationScreen(
                conversationId = activeConvId!!,
                viewModel = viewModel
            )
        } else {
            if (isWideScreen) {
                // Adaptive layout: NavigationRail on side
                Row(modifier = Modifier.fillMaxSize()) {
                    NavigationRail(
                        containerColor = TchatSurfaceDark,
                        contentColor = TchatWhite,
                        modifier = Modifier.width(80.dp)
                    ) {
                        Spacer(modifier = Modifier.height(16.dp))

                        NavigationRailItem(
                            selected = currentTab == MainTab.CHATS,
                            onClick = { viewModel.selectTab(MainTab.CHATS) },
                            icon = {
                                BadgedBox(
                                    badge = {
                                        if (totalUnread > 0) {
                                            Badge(containerColor = TchatRed, contentColor = TchatWhite) {
                                                Text(totalUnread.toString())
                                            }
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.ChatBubble, contentDescription = "Chats")
                                }
                            },
                            label = { Text("Chats", fontSize = 10.sp) },
                            colors = navigationRailItemColors()
                        )

                        NavigationRailItem(
                            selected = currentTab == MainTab.CALLS,
                            onClick = { viewModel.selectTab(MainTab.CALLS) },
                            icon = { Icon(Icons.Default.Call, contentDescription = "Calls") },
                            label = { Text("Calls", fontSize = 10.sp) },
                            colors = navigationRailItemColors()
                        )

                        NavigationRailItem(
                            selected = currentTab == MainTab.UPDATES,
                            onClick = { viewModel.selectTab(MainTab.UPDATES) },
                            icon = { Icon(Icons.Default.DonutLarge, contentDescription = "Updates") },
                            label = { Text("Updates", fontSize = 10.sp) },
                            colors = navigationRailItemColors()
                        )

                        NavigationRailItem(
                            selected = currentTab == MainTab.COMMUNITIES,
                            onClick = { viewModel.selectTab(MainTab.COMMUNITIES) },
                            icon = { Icon(Icons.Default.Groups, contentDescription = "Communities") },
                            label = { Text("Network", fontSize = 10.sp) },
                            colors = navigationRailItemColors()
                        )

                        NavigationRailItem(
                            selected = currentTab == MainTab.TECHSTARC_AI,
                            onClick = { viewModel.selectTab(MainTab.TECHSTARC_AI) },
                            icon = { Icon(Icons.Default.AutoAwesome, contentDescription = "AI") },
                            label = { Text("AI", fontSize = 10.sp) },
                            colors = navigationRailItemColors()
                        )

                        NavigationRailItem(
                            selected = currentTab == MainTab.SETTINGS,
                            onClick = { viewModel.selectTab(MainTab.SETTINGS) },
                            icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                            label = { Text("Settings", fontSize = 10.sp) },
                            colors = navigationRailItemColors()
                        )
                    }

                    Box(modifier = Modifier.weight(1f)) {
                        TabContent(currentTab = currentTab, viewModel = viewModel)
                    }
                }
            } else {
                // Mobile layout: BottomNavigationBar with 6 items
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        NavigationBar(
                            containerColor = TchatSurfaceDark,
                            contentColor = TchatWhite,
                            tonalElevation = 8.dp
                        ) {
                            NavigationBarItem(
                                selected = currentTab == MainTab.CHATS,
                                onClick = { viewModel.selectTab(MainTab.CHATS) },
                                icon = {
                                    BadgedBox(
                                        badge = {
                                            if (totalUnread > 0) {
                                                Badge(containerColor = TchatRed, contentColor = TchatWhite) {
                                                    Text(totalUnread.toString())
                                                }
                                            }
                                        }
                                    ) {
                                        Icon(Icons.Default.ChatBubble, contentDescription = "Chats")
                                    }
                                },
                                label = { Text("Chats", fontSize = 10.sp) },
                                colors = navItemColors()
                            )

                            NavigationBarItem(
                                selected = currentTab == MainTab.CALLS,
                                onClick = { viewModel.selectTab(MainTab.CALLS) },
                                icon = { Icon(Icons.Default.Call, contentDescription = "Calls") },
                                label = { Text("Calls", fontSize = 10.sp) },
                                colors = navItemColors()
                            )

                            NavigationBarItem(
                                selected = currentTab == MainTab.UPDATES,
                                onClick = { viewModel.selectTab(MainTab.UPDATES) },
                                icon = { Icon(Icons.Default.DonutLarge, contentDescription = "Updates") },
                                label = { Text("Updates", fontSize = 10.sp) },
                                colors = navItemColors()
                            )

                            NavigationBarItem(
                                selected = currentTab == MainTab.COMMUNITIES,
                                onClick = { viewModel.selectTab(MainTab.COMMUNITIES) },
                                icon = { Icon(Icons.Default.Groups, contentDescription = "Communities") },
                                label = { Text("Communities", fontSize = 9.sp) },
                                colors = navItemColors()
                            )

                            NavigationBarItem(
                                selected = currentTab == MainTab.TECHSTARC_AI,
                                onClick = { viewModel.selectTab(MainTab.TECHSTARC_AI) },
                                icon = { Icon(Icons.Default.AutoAwesome, contentDescription = "AI") },
                                label = { Text("AI", fontSize = 10.sp) },
                                colors = navItemColors()
                            )

                            NavigationBarItem(
                                selected = currentTab == MainTab.SETTINGS,
                                onClick = { viewModel.selectTab(MainTab.SETTINGS) },
                                icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                                label = { Text("Settings", fontSize = 10.sp) },
                                colors = navItemColors()
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        TabContent(currentTab = currentTab, viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun TabContent(currentTab: MainTab, viewModel: TchatViewModel) {
    Crossfade(targetState = currentTab, label = "tabTransition") { tab ->
        when (tab) {
            MainTab.CHATS -> ChatsScreen(viewModel = viewModel)
            MainTab.CALLS -> CallsScreen(viewModel = viewModel)
            MainTab.UPDATES -> StatusScreen(viewModel = viewModel)
            MainTab.COMMUNITIES -> CommunitiesScreen(viewModel = viewModel)
            MainTab.TECHSTARC_AI -> TechstarcAiScreen(viewModel = viewModel)
            MainTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
        }
    }
}

@Composable
fun navItemColors(): NavigationBarItemColors {
    return NavigationBarItemDefaults.colors(
        selectedIconColor = TchatYellow,
        selectedTextColor = TchatYellow,
        unselectedIconColor = TchatTextSecondary,
        unselectedTextColor = TchatTextSecondary,
        indicatorColor = TchatSurfaceElevated
    )
}

@Composable
fun navigationRailItemColors(): NavigationRailItemColors {
    return NavigationRailItemDefaults.colors(
        selectedIconColor = TchatYellow,
        selectedTextColor = TchatYellow,
        unselectedIconColor = TchatTextSecondary,
        unselectedTextColor = TchatTextSecondary,
        indicatorColor = TchatSurfaceElevated
    )
}
