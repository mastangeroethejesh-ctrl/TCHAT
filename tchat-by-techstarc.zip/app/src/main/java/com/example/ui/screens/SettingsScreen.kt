package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.TchatViewModel
import com.example.ui.components.TchatAvatar
import com.example.ui.components.TchatLogo
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: TchatViewModel,
    modifier: Modifier = Modifier
) {
    val currentUser by viewModel.currentUser.collectAsState()
    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showDeleteAccountDialog by remember { mutableStateOf(false) }
    var notificationsEnabled by remember { mutableStateOf(true) }
    var readReceiptsEnabled by remember { mutableStateOf(true) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = TchatDarkBg,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Settings",
                        color = TchatWhite,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = TchatSurfaceDark)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Profile Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showEditProfileDialog = true },
                colors = CardDefaults.cardColors(containerColor = TchatSurfaceDark),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TchatAvatar(name = currentUser.displayName, size = 60.dp, isOnline = true)
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = currentUser.displayName,
                            color = TchatWhite,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = currentUser.username,
                            color = TchatYellow,
                            fontSize = 13.sp
                        )
                        Text(
                            text = currentUser.bio,
                            color = TchatTextSecondary,
                            fontSize = 12.sp,
                            maxLines = 1,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Edit Profile",
                        tint = TchatYellow
                    )
                }
            }

            // Brand & Company Showcase Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = TchatSurfaceElevated),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TchatLogo(size = 40.dp, animated = false)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Tchat",
                                color = TchatWhite,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Techstarc.chat • Founded by Thejesh",
                                color = TchatYellow,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Built with high-velocity Kotlin, Jetpack Compose, Room persistence, WebRTC signaling architecture, and Google Gemini AI.",
                        color = TchatTextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }
            }

            // Preferences Section
            Text(
                text = "PREFERENCES & PRIVACY",
                color = TchatYellow,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = TchatSurfaceDark),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column {
                    SettingsToggleRow(
                        icon = Icons.Default.Notifications,
                        title = "Push Notifications",
                        subtitle = "Messages, WebRTC calls, and mentions",
                        checked = notificationsEnabled,
                        onCheckedChange = { notificationsEnabled = it }
                    )
                    HorizontalDivider(color = TchatBorder, thickness = 0.5.dp)
                    SettingsToggleRow(
                        icon = Icons.Default.DoneAll,
                        title = "Read Receipts",
                        subtitle = "Double ticks show when messages are read",
                        checked = readReceiptsEnabled,
                        onCheckedChange = { readReceiptsEnabled = it }
                    )
                    HorizontalDivider(color = TchatBorder, thickness = 0.5.dp)
                    SettingsClickRow(
                        icon = Icons.Default.Visibility,
                        title = "Last Seen & Online",
                        value = currentUser.statusPrivacy,
                        onClick = { showEditProfileDialog = true }
                    )
                    HorizontalDivider(color = TchatBorder, thickness = 0.5.dp)
                    SettingsClickRow(
                        icon = Icons.Default.Wallpaper,
                        title = "Chat Wallpaper",
                        value = "Techstarc Dark",
                        onClick = { /* Wallpaper */ }
                    )
                }
            }

            // Account Actions Section
            Text(
                text = "ACCOUNT MANAGEMENT",
                color = TchatYellow,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = TchatSurfaceDark),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.logout() }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Logout, contentDescription = null, tint = TchatYellow)
                        Spacer(modifier = Modifier.width(14.dp))
                        Text(
                            text = "Log Out of Tchat",
                            color = TchatWhite,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    HorizontalDivider(color = TchatBorder, thickness = 0.5.dp)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showDeleteAccountDialog = true }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.DeleteForever, contentDescription = null, tint = TchatRed)
                        Spacer(modifier = Modifier.width(14.dp))
                        Text(
                            text = "Delete Account & Data",
                            color = TchatRed,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    // Edit Profile Dialog
    if (showEditProfileDialog) {
        var name by remember { mutableStateOf(currentUser.displayName) }
        var bio by remember { mutableStateOf(currentUser.bio) }
        var privacy by remember { mutableStateOf(currentUser.statusPrivacy) }

        AlertDialog(
            onDismissRequest = { showEditProfileDialog = false },
            containerColor = TchatSurfaceDark,
            title = {
                Text("Edit Profile & Privacy", color = TchatWhite, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Display Name", color = TchatTextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TchatWhite,
                            unfocusedTextColor = TchatWhite,
                            focusedBorderColor = TchatYellow,
                            unfocusedBorderColor = TchatBorder
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = bio,
                        onValueChange = { bio = it },
                        label = { Text("Bio", color = TchatTextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TchatWhite,
                            unfocusedTextColor = TchatWhite,
                            focusedBorderColor = TchatYellow,
                            unfocusedBorderColor = TchatBorder
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("Last Seen Visibility", color = TchatWhite, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Everyone", "Contacts", "Nobody").forEach { opt ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (privacy == opt) TchatRed else TchatSurfaceElevated)
                                    .clickable { privacy = opt }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(opt, color = TchatWhite, fontSize = 12.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateProfile(name, bio, privacy)
                        showEditProfileDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TchatRed)
                ) {
                    Text("Save Changes", color = TchatWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditProfileDialog = false }) {
                    Text("Cancel", color = TchatTextSecondary)
                }
            }
        )
    }

    // Delete Account Confirmation Dialog
    if (showDeleteAccountDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteAccountDialog = false },
            containerColor = TchatSurfaceDark,
            title = {
                Text("Delete Account?", color = TchatRed, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    text = "This will permanently remove your profile, local message history, and account credentials from Tchat. This action cannot be reversed.",
                    color = TchatTextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteAccountDialog = false
                        viewModel.logout()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TchatRed)
                ) {
                    Text("Delete Everything", color = TchatWhite)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAccountDialog = false }) {
                    Text("Cancel", color = TchatTextSecondary)
                }
            }
        )
    }
}

@Composable
fun SettingsToggleRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = TchatYellow, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(text = title, color = TchatWhite, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                Text(text = subtitle, color = TchatTextMuted, fontSize = 11.sp)
            }
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = TchatWhite,
                checkedTrackColor = TchatRed,
                uncheckedTrackColor = TchatSurfaceElevated
            )
        )
    }
}

@Composable
fun SettingsClickRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    value: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = TchatYellow, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.width(14.dp))
            Text(text = title, color = TchatWhite, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = value, color = TchatTextSecondary, fontSize = 13.sp)
            Spacer(modifier = Modifier.width(6.dp))
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TchatTextMuted, modifier = Modifier.size(18.dp))
        }
    }
}
