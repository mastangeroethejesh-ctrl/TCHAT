package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.TchatViewModel
import com.example.ui.components.TchatLogo
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    viewModel: TchatViewModel,
    modifier: Modifier = Modifier
) {
    var authMode by remember { mutableStateOf("EMAIL") } // "EMAIL", "PHONE"
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var showRecoveryDialog by remember { mutableStateOf(false) }
    var recoveryEmail by remember { mutableStateOf("") }
    var recoverySuccess by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(TchatDarkBg)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Branded Logo Header
            TchatLogo(size = 72.dp, animated = true)

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Welcome to Tchat",
                color = TchatWhite,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "Techstarc.chat • Founded by Thejesh",
                color = TchatYellow,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
            )

            // Auth Mode Toggle (Email / Phone)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(TchatSurfaceElevated)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (authMode == "EMAIL") TchatRed else Color.Transparent)
                        .clickable { authMode = "EMAIL" }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Email Sign In",
                        color = TchatWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (authMode == "PHONE") TchatRed else Color.Transparent)
                        .clickable { authMode = "PHONE" }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Phone Number",
                        color = TchatWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            if (authMode == "EMAIL") {
                // Email Field
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email address", color = TchatTextSecondary) },
                    singleLine = true,
                    leadingIcon = {
                        Icon(Icons.Default.Email, contentDescription = null, tint = TchatYellow)
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TchatWhite,
                        unfocusedTextColor = TchatWhite,
                        focusedBorderColor = TchatYellow,
                        unfocusedBorderColor = TchatBorder,
                        focusedContainerColor = TchatSurfaceDark,
                        unfocusedContainerColor = TchatSurfaceDark
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Password Field
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password", color = TchatTextSecondary) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    leadingIcon = {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = TchatYellow)
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TchatWhite,
                        unfocusedTextColor = TchatWhite,
                        focusedBorderColor = TchatYellow,
                        unfocusedBorderColor = TchatBorder,
                        focusedContainerColor = TchatSurfaceDark,
                        unfocusedContainerColor = TchatSurfaceDark
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    Text(
                        text = "Forgot password?",
                        color = TchatYellow,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.clickable { showRecoveryDialog = true }
                    )
                }
            } else {
                // Phone Number Field
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone (+1 ...)", color = TchatTextSecondary) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    leadingIcon = {
                        Icon(Icons.Default.Phone, contentDescription = null, tint = TchatYellow)
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TchatWhite,
                        unfocusedTextColor = TchatWhite,
                        focusedBorderColor = TchatYellow,
                        unfocusedBorderColor = TchatBorder,
                        focusedContainerColor = TchatSurfaceDark,
                        unfocusedContainerColor = TchatSurfaceDark
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Primary Sign In Button (Red Brand Color)
            Button(
                onClick = {
                    if (authMode == "EMAIL") {
                        viewModel.loginWithEmail(if (email.isNotBlank()) email else "thejesh.team@techstarc.chat")
                    } else {
                        viewModel.loginWithPhone(if (phone.isNotBlank()) phone else "+1 555-842-8727")
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = TchatRed),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = if (authMode == "EMAIL") "Sign In to Tchat" else "Send Verification Code",
                    color = TchatWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Divider
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.weight(1f).height(1.dp).background(TchatBorder))
                Text(
                    text = "OR",
                    color = TchatTextMuted,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
                Box(modifier = Modifier.weight(1f).height(1.dp).background(TchatBorder))
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Google Sign-In Button (Complies with White/Yellow/Red branding)
            OutlinedButton(
                onClick = { viewModel.loginWithGoogle() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TchatYellow),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = TchatSurfaceDark,
                    contentColor = TchatWhite
                )
            ) {
                Icon(
                    imageVector = Icons.Default.AccountCircle,
                    contentDescription = null,
                    tint = TchatYellow,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Continue with Google",
                    color = TchatWhite,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Quick Guest Demo Access Button
            TextButton(
                onClick = { viewModel.loginWithEmail("guest@techstarc.chat") }
            ) {
                Text(
                    text = "Quick Demo Access (Explore Tchat)",
                    color = TchatYellow,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }

    // Account Recovery Dialog
    if (showRecoveryDialog) {
        AlertDialog(
            onDismissRequest = {
                showRecoveryDialog = false
                recoverySuccess = false
            },
            containerColor = TchatSurfaceDark,
            title = {
                Text(
                    text = if (recoverySuccess) "Recovery Link Sent" else "Account Recovery",
                    color = TchatWhite,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                if (recoverySuccess) {
                    Text(
                        text = "A password reset link has been dispatched to $recoveryEmail. Please verify your inbox.",
                        color = TchatTextSecondary
                    )
                } else {
                    Column {
                        Text(
                            text = "Enter the email associated with your Tchat account to receive recovery instructions.",
                            color = TchatTextSecondary,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = recoveryEmail,
                            onValueChange = { recoveryEmail = it },
                            label = { Text("Email", color = TchatTextSecondary) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TchatWhite,
                                unfocusedTextColor = TchatWhite,
                                focusedBorderColor = TchatYellow,
                                unfocusedBorderColor = TchatBorder
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                if (!recoverySuccess) {
                    Button(
                        onClick = {
                            if (recoveryEmail.isNotBlank()) {
                                recoverySuccess = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TchatRed)
                    ) {
                        Text("Send Reset Link", color = TchatWhite)
                    }
                } else {
                    Button(
                        onClick = {
                            showRecoveryDialog = false
                            recoverySuccess = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TchatRed)
                    ) {
                        Text("Done", color = TchatWhite)
                    }
                }
            },
            dismissButton = {
                if (!recoverySuccess) {
                    TextButton(onClick = { showRecoveryDialog = false }) {
                        Text("Cancel", color = TchatTextSecondary)
                    }
                }
            }
        )
    }
}
