package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.TchatRed
import com.example.ui.theme.TchatWhite
import com.example.ui.theme.TchatYellow

/**
 * Official Tchat Logo Composable.
 * Preserves the original T shape, chat bubble, and brand identity
 * with White (#FFFFFF), Yellow (#FFC107), and Red (#E53935).
 * Features cinematic glossy highlights and subtle 3D-inspired lighting.
 */
@Composable
fun TchatLogo(
    modifier: Modifier = Modifier,
    size: Dp = 80.dp,
    animated: Boolean = true
) {
    val infiniteTransition = rememberInfiniteTransition(label = "TchatLogoPulse")
    val shimmerOffset by if (animated) {
        infiniteTransition.animateFloat(
            initialValue = -0.5f,
            targetValue = 1.5f,
            animationSpec = infiniteRepeatable(
                animation = tween(2800, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "shimmer"
        )
    } else {
        rememberInfiniteTransition(label = "static").animateFloat(
            initialValue = 0f, targetValue = 0f,
            animationSpec = infiniteRepeatable(tween(1)), label = "static"
        )
    }

    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = this.size.width
            val h = this.size.height

            // 1. Ambient Brand Glow (Red to Yellow)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        TchatRed.copy(alpha = 0.35f * glowAlpha),
                        TchatYellow.copy(alpha = 0.15f * glowAlpha),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.5f, h * 0.5f),
                    radius = w * 0.55f
                ),
                radius = w * 0.55f
            )

            // 2. Chat Bubble Base (Rounded Rectangle with Speech Tail)
            val bubbleLeft = w * 0.16f
            val bubbleTop = h * 0.16f
            val bubbleWidth = w * 0.68f
            val bubbleHeight = h * 0.58f
            val cornerRadius = w * 0.18f

            // Shadow / 3D depth layer
            drawRoundRect(
                color = Color.Black.copy(alpha = 0.35f),
                topLeft = Offset(bubbleLeft + w * 0.015f, bubbleTop + h * 0.025f),
                size = Size(bubbleWidth, bubbleHeight),
                cornerRadius = CornerRadius(cornerRadius, cornerRadius)
            )

            // White Chat Bubble Body
            drawRoundRect(
                color = TchatWhite,
                topLeft = Offset(bubbleLeft, bubbleTop),
                size = Size(bubbleWidth, bubbleHeight),
                cornerRadius = CornerRadius(cornerRadius, cornerRadius)
            )

            // Chat Bubble Speech Tail
            val tailPath = Path().apply {
                moveTo(bubbleLeft + bubbleWidth * 0.18f, bubbleTop + bubbleHeight)
                lineTo(bubbleLeft + bubbleWidth * 0.10f, bubbleTop + bubbleHeight + h * 0.13f)
                lineTo(bubbleLeft + bubbleWidth * 0.38f, bubbleTop + bubbleHeight)
                close()
            }
            drawPath(tailPath, color = TchatWhite)

            // 3. Subtle Inner Yellow Brand Accent Border inside Bubble
            drawRoundRect(
                color = TchatYellow.copy(alpha = 0.35f),
                topLeft = Offset(bubbleLeft + 2.dp.toPx(), bubbleTop + 2.dp.toPx()),
                size = Size(bubbleWidth - 4.dp.toPx(), bubbleHeight - 4.dp.toPx()),
                cornerRadius = CornerRadius(cornerRadius - 2.dp.toPx(), cornerRadius - 2.dp.toPx()),
                style = Stroke(width = 2.dp.toPx())
            )

            // 4. Bold Iconic "T" Letterform in Red (#E53935)
            val barLeft = bubbleLeft + bubbleWidth * 0.20f
            val barRight = bubbleLeft + bubbleWidth * 0.80f
            val barTop = bubbleTop + bubbleHeight * 0.22f
            val barHeight = bubbleHeight * 0.18f

            val stemWidth = bubbleWidth * 0.22f
            val stemLeft = (bubbleLeft + bubbleWidth * 0.5f) - (stemWidth * 0.5f)
            val stemTop = barTop + barHeight
            val stemBottom = bubbleTop + bubbleHeight * 0.78f

            // Top Crossbar of T
            drawRoundRect(
                color = TchatRed,
                topLeft = Offset(barLeft, barTop),
                size = Size(barRight - barLeft, barHeight),
                cornerRadius = CornerRadius(barHeight * 0.3f, barHeight * 0.3f)
            )

            // Vertical Stem of T
            drawRoundRect(
                color = TchatRed,
                topLeft = Offset(stemLeft, stemTop - 1.dp.toPx()),
                size = Size(stemWidth, stemBottom - stemTop + 1.dp.toPx()),
                cornerRadius = CornerRadius(stemWidth * 0.2f, stemWidth * 0.2f)
            )

            // 5. Techstarc Spark / Tech Accent (Yellow #FFC107)
            val sparkX = bubbleLeft + bubbleWidth * 0.76f
            val sparkY = bubbleTop + bubbleHeight * 0.70f
            val sparkRadius = w * 0.055f

            // Spark glow
            drawCircle(
                color = TchatYellow.copy(alpha = 0.4f * glowAlpha),
                radius = sparkRadius * 1.6f,
                center = Offset(sparkX, sparkY)
            )
            // Spark dot
            drawCircle(
                color = TchatYellow,
                radius = sparkRadius,
                center = Offset(sparkX, sparkY)
            )

            // 6. Cinematic Glossy Shimmer Highlight across the Logo
            if (animated) {
                val shimmerX = w * shimmerOffset
                val shimmerBrush = Brush.linearGradient(
                    colors = listOf(
                        Color.Transparent,
                        TchatWhite.copy(alpha = 0.4f),
                        TchatYellow.copy(alpha = 0.3f),
                        Color.Transparent
                    ),
                    start = Offset(shimmerX - w * 0.25f, 0f),
                    end = Offset(shimmerX + w * 0.25f, h)
                )
                drawRoundRect(
                    brush = shimmerBrush,
                    topLeft = Offset(bubbleLeft, bubbleTop),
                    size = Size(bubbleWidth, bubbleHeight),
                    cornerRadius = CornerRadius(cornerRadius, cornerRadius)
                )
            }
        }
    }
}
