package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Tchat Official Brand Colors
val TchatRed = Color(0xFFE53935)
val TchatYellow = Color(0xFFFFC107)
val TchatWhite = Color(0xFFFFFFFF)

// Dark Neutrals for Contrast & Accessibility
val TchatBlack = Color(0xFF0F0F0F)
val TchatDarkBg = Color(0xFF141414)
val TchatSurfaceDark = Color(0xFF1E1E1E)
val TchatSurfaceElevated = Color(0xFF282828)
val TchatBorder = Color(0xFF333333)
val TchatTextPrimary = Color(0xFFFFFFFF)
val TchatTextSecondary = Color(0xFFB0B0B0)
val TchatTextMuted = Color(0xFF757575)

// Light Neutrals for Light Theme
val TchatLightBg = Color(0xFFF9F9F9)
val TchatLightSurface = Color(0xFFFFFFFF)
val TchatLightSurfaceElevated = Color(0xFFF0F0F0)
val TchatLightBorder = Color(0xFFE0E0E0)
val TchatLightTextPrimary = Color(0xFF121212)
val TchatLightTextSecondary = Color(0xFF555555)
