package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.TchatRepository
import com.example.model.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class MainTab {
    CHATS, CALLS, UPDATES, COMMUNITIES, TECHSTARC_AI, SETTINGS
}

data class CallState(
    val isActive: Boolean = false,
    val contactName: String = "",
    val isVideo: Boolean = false,
    val status: String = "Connecting...", // "Calling...", "Ringing...", "Connected", "Call Ended"
    val isMuted: Boolean = false,
    val isSpeakerOn: Boolean = false,
    val isCameraOn: Boolean = true,
    val durationSeconds: Int = 0
)

class TchatViewModel(application: Application) : AndroidViewModel(application) {
    val repository = TchatRepository(application)

    // Current Navigation / App View
    val currentTab = MutableStateFlow(MainTab.CHATS)
    val activeConversationId = MutableStateFlow<String?>(null)
    val showSplashScreen = MutableStateFlow(true)
    val isLoggedIn = MutableStateFlow(true) // Onboarding & Auth toggle

    // Current User Profile
    val currentUser = MutableStateFlow(
        User(
            id = "me",
            displayName = "Thejesh's Guest",
            username = "@tchat_pioneer",
            email = "thejesh.team@techstarc.chat",
            phoneNumber = "+1 (555) 842-8727",
            bio = "Building high-performance apps with Techstarc.chat"
        )
    )

    // Data streams from repository
    val activeConversations: StateFlow<List<Conversation>> = repository.getActiveConversations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val archivedConversations: StateFlow<List<Conversation>> = repository.getArchivedConversations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val callLogs: StateFlow<List<CallLog>> = repository.getCallLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val statusUpdates: StateFlow<List<StatusUpdate>> = repository.getStatusUpdates()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val communities: StateFlow<List<Community>> = repository.getCommunities()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val aiMessages: StateFlow<List<AiMessage>> = repository.getAiMessages()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active conversation messages
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val currentMessages: StateFlow<List<Message>> = activeConversationId
        .flatMapLatest { id ->
            if (id != null) repository.getMessagesForConversation(id) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Call Engine State
    val callState = MutableStateFlow(CallState())
    private var callTimerJob: Job? = null

    // Voice Note Recording
    val isRecordingVoice = MutableStateFlow(false)
    val voiceRecordingSeconds = MutableStateFlow(0)
    private var voiceTimerJob: Job? = null

    // Status Viewer
    val viewingStatus = MutableStateFlow<StatusUpdate?>(null)

    // Techstarc AI Loading State
    val isAiGenerating = MutableStateFlow(false)

    // Search query
    val searchQuery = MutableStateFlow("")

    init {
        // Automatically transition out of splash screen after cinematic reveal
        viewModelScope.launch {
            delay(2400)
            showSplashScreen.value = false
        }
    }

    fun selectTab(tab: MainTab) {
        currentTab.value = tab
    }

    fun openConversation(id: String) {
        activeConversationId.value = id
    }

    fun closeConversation() {
        activeConversationId.value = null
    }

    fun sendMessage(
        text: String,
        type: String = "TEXT",
        mediaUrl: String = "",
        voiceDurationSeconds: Int = 0,
        replyToText: String = "",
        replyToSender: String = ""
    ) {
        val convId = activeConversationId.value ?: return
        viewModelScope.launch {
            repository.sendMessage(
                conversationId = convId,
                text = text,
                type = type,
                mediaUrl = mediaUrl,
                voiceDurationSeconds = voiceDurationSeconds,
                replyToText = replyToText,
                replyToSender = replyToSender
            )
        }
    }

    fun startVoiceRecording() {
        isRecordingVoice.value = true
        voiceRecordingSeconds.value = 0
        voiceTimerJob?.cancel()
        voiceTimerJob = viewModelScope.launch {
            while (isRecordingVoice.value) {
                delay(1000)
                voiceRecordingSeconds.value += 1
            }
        }
    }

    fun stopAndSendVoiceRecording() {
        val duration = voiceRecordingSeconds.value
        isRecordingVoice.value = false
        voiceTimerJob?.cancel()
        if (duration >= 1) {
            sendMessage(
                text = "Voice message",
                type = "VOICE",
                voiceDurationSeconds = duration
            )
        }
    }

    fun cancelVoiceRecording() {
        isRecordingVoice.value = false
        voiceTimerJob?.cancel()
        voiceRecordingSeconds.value = 0
    }

    fun addReaction(messageId: String, reaction: String) {
        viewModelScope.launch {
            repository.addReaction(messageId, reaction)
        }
    }

    fun toggleStar(messageId: String) {
        viewModelScope.launch {
            repository.toggleStar(messageId)
        }
    }

    fun deleteMessage(messageId: String) {
        viewModelScope.launch {
            repository.deleteMessage(messageId)
        }
    }

    fun togglePinChat(id: String) {
        viewModelScope.launch { repository.togglePinChat(id) }
    }

    fun toggleArchiveChat(id: String) {
        viewModelScope.launch { repository.toggleArchiveChat(id) }
    }

    fun toggleMuteChat(id: String) {
        viewModelScope.launch { repository.toggleMuteChat(id) }
    }

    fun deleteChat(id: String) {
        viewModelScope.launch {
            repository.deleteConversation(id)
            if (activeConversationId.value == id) {
                activeConversationId.value = null
            }
        }
    }

    fun createChat(name: String, isGroup: Boolean, initialMessage: String = "") {
        viewModelScope.launch {
            val newId = repository.createNewChat(name, isGroup, initialMessage)
            activeConversationId.value = newId
        }
    }

    // Call Engine Simulation with realistic WebRTC signaling states
    fun startCall(contactName: String, isVideo: Boolean) {
        callState.value = CallState(
            isActive = true,
            contactName = contactName,
            isVideo = isVideo,
            status = "Calling..."
        )
        callTimerJob?.cancel()
        callTimerJob = viewModelScope.launch {
            delay(1500)
            callState.value = callState.value.copy(status = "Ringing...")
            delay(2000)
            callState.value = callState.value.copy(status = "Connected (HD Audio/Video)")
            var sec = 0
            while (callState.value.isActive) {
                delay(1000)
                sec++
                callState.value = callState.value.copy(durationSeconds = sec)
            }
        }
    }

    fun endCall() {
        val duration = callState.value.durationSeconds
        val contact = callState.value.contactName
        val isVideo = callState.value.isVideo
        callTimerJob?.cancel()
        callState.value = callState.value.copy(status = "Call Ended")

        viewModelScope.launch {
            delay(800)
            callState.value = CallState(isActive = false)
            val durationText = "${duration / 60}m ${duration % 60}s"
            repository.recordCallLog(
                contactName = contact,
                isVideo = isVideo,
                isOutgoing = true,
                isMissed = duration == 0,
                duration = if (duration == 0) "Missed" else durationText
            )
        }
    }

    fun toggleCallMute() {
        callState.value = callState.value.copy(isMuted = !callState.value.isMuted)
    }

    fun toggleCallSpeaker() {
        callState.value = callState.value.copy(isSpeakerOn = !callState.value.isSpeakerOn)
    }

    fun toggleCallCamera() {
        callState.value = callState.value.copy(isCameraOn = !callState.value.isCameraOn)
    }

    // Status
    fun postStatus(content: String, bgHex: String = "#E53935") {
        viewModelScope.launch {
            repository.postStatus(content, "TEXT", bgHex)
        }
    }

    fun openStatus(status: StatusUpdate) {
        viewingStatus.value = status
        viewModelScope.launch {
            repository.markStatusViewed(status.id)
        }
    }

    fun closeStatus() {
        viewingStatus.value = null
    }

    // Communities
    fun toggleCommunitySubscription(id: String) {
        viewModelScope.launch {
            repository.toggleCommunitySubscription(id)
        }
    }

    // Techstarc AI
    fun askTechstarcAi(prompt: String, category: String = "General") {
        if (prompt.isBlank()) return
        isAiGenerating.value = true
        viewModelScope.launch {
            repository.askTechstarcAi(prompt, category)
            isAiGenerating.value = false
        }
    }

    // Profile & Settings
    fun updateProfile(displayName: String, bio: String, statusPrivacy: String) {
        currentUser.value = currentUser.value.copy(
            displayName = displayName,
            bio = bio,
            statusPrivacy = statusPrivacy
        )
    }

    fun logout() {
        isLoggedIn.value = false
    }

    fun loginWithEmail(email: String) {
        currentUser.value = currentUser.value.copy(email = email)
        isLoggedIn.value = true
    }

    fun loginWithGoogle() {
        currentUser.value = currentUser.value.copy(
            displayName = "Thejesh Verified",
            email = "user@techstarc.chat"
        )
        isLoggedIn.value = true
    }

    fun loginWithPhone(phone: String) {
        currentUser.value = currentUser.value.copy(phoneNumber = phone)
        isLoggedIn.value = true
    }
}
